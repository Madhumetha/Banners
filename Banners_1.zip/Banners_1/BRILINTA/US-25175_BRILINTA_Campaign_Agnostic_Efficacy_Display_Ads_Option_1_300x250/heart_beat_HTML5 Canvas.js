(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"heart_beat_HTML5 Canvas_atlas_", frames: [[0,0,61,44],[0,46,61,44]]}
];


// symbols:



(lib.heart1 = function() {
	this.spriteSheet = ss["heart_beat_HTML5 Canvas_atlas_"];
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.heart_line = function() {
	this.spriteSheet = ss["heart_beat_HTML5 Canvas_atlas_"];
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



// stage content:
(lib.heart_beat_HTML5Canvas = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Layer_12 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_15 = new cjs.Graphics().p("AA8CWIg6gBQgJAAgHgIQgHgHAAgKQAAgLAIgHQAHgHAJAAIAsABQAAAFAFAGQAGAGABAKQABAJAFAHQAFAHgKAAIAAAAg");
	var mask_graphics_16 = new cjs.Graphics().p("AAKBeIg5gBQgKgBgHgHQgHgHAAgLQAAgKAIgHQAHgHAKAAIA4ACQgNgFAth5QAEgKAJgEQAKgEgHAPQgHAOAQACQAQABgjBXQgeBMgGAAQgBAAAAAAQAAAAAAAAQAAAAgBgBQAAAAAAgBg");
	var mask_graphics_17 = new cjs.Graphics().p("ABWC3QgJgFgCgKIgYiFQgjBSgLgEIg5gCQgLAAgHgHQgHgIAAgKQAAgKAIgHQAHgHALAAIA4ABQgOgEAth5QADgIAIgEQAHgFAIABQAIABAGAFQAGAGACAIQADBwAgBtQAHAGgGAIQgGAJgKABIgFABQgHAAgGgFg");
	var mask_graphics_18 = new cjs.Graphics().p("ABRC8QgIAAgHgGQgHgGgBgIIgZiFQgiBSgLgEIg6gCQgKAAgHgHQgIgIABgKQAAgKAHgHQAIgHAKAAIA5ABQgPgEAuh5QADgIAHgEQAHgFAIABQAIABAHAFQAGAGABAIIATBmIAIghQACgKAJgEQAJgGAKADQAJACAGAIQAFAIgHAHQgdBEgBBSQgCAIgHAGQgHAFgIAAIgBAAg");
	var mask_graphics_19 = new cjs.Graphics().p("ABJC8QgJAAgHgGQgGgGgCgIIgYiFQgiBSgMgEIg6gCQgKAAgHgHQgHgIAAgKQAAgKAIgHQAHgHAKAAIA5ABQgOgEAth5QADgIAHgEQAHgFAJABQAIABAGAFQAGAGACAIIATBmIAHghQACgIAHgEQAGgGAIAAQAIgBAHAFQAHAEADAHQAWA/gQADQALAAgLALQgLAKALAJQAKAIABAGQAAAGgLAAQgIAEgQgeIgRBHQgCAIgHAGQgGAFgJAAIAAAAg");
	var mask_graphics_20 = new cjs.Graphics().p("AgwCAQgGgGgCgJIgYiEQgkBSgLgEIg6gCQgKAAgHgHQgHgIAAgKQAAgKAIgHQAHgIAKABIA5ABQgOgFAuh4QADgIAHgFQAHgEAJABQAIAAAGAGQAGAGACAIIATBnIAHghQACgIAHgGQAGgFAHAAQAIgBAHAFQAHAEADAIQAVA9gPAEICZgBQAKAAAHAHQAHAHABALQAAAKgIAHQgHAHgKABIiZABQgJADgPgeIgQBIQgCAIgHAFQgHAGgIAAQgJgBgHgFg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(15).to({graphics:mask_graphics_15,x:6.7,y:15}).wait(1).to({graphics:mask_graphics_16,x:11.7,y:20.7}).wait(1).to({graphics:mask_graphics_17,x:12.2,y:18.8}).wait(1).to({graphics:mask_graphics_18,x:14,y:18.8}).wait(1).to({graphics:mask_graphics_19,x:14.9,y:18.8}).wait(1).to({graphics:mask_graphics_20,x:25.5,y:24.2}).wait(1).to({graphics:null,x:0,y:0}).wait(27));

	// Layer_8
	this.instance = new lib.heart_line();
	this.instance.parent = this;
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(15).to({_off:false},0).wait(10).to({scaleX:1.05,scaleY:1.05,x:-1,y:-1},0).wait(4).to({scaleX:1,scaleY:1,x:0,y:0},0).wait(4).to({scaleX:1.05,scaleY:1.05,x:-1,y:-1},0).wait(4).to({scaleX:1,scaleY:1,x:0,y:0},0).wait(4).to({scaleX:1.05,scaleY:1.05,x:-1,y:-1},0).wait(4).to({scaleX:1,scaleY:1,x:0,y:0},0).wait(3));

	// Layer_11 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("AAdA8QgEAAgDgCQgGgBgEgFIgDgDIAAAAIAAgBIgBgBIgBgBIgKgNIgwg0QgHgHABgKQABgLAHgHQAIgHAKABQAKABAHAHIAvA1IAMANIADAEIACADIACAEIAAgBQARAlgeAAIgKgBg");
	var mask_1_graphics_1 = new cjs.Graphics().p("ABdDhIgIgBQgFgBgFgFIgDgEIABABIgBgBIAAAAIAAgBIgBAAIAAgBIgMgNIgngrIgIgKIgBgBIAAAAIgBAAIgKgKIgoglQgIgHAAgKQgBgKAHgIQAHgHAKgBQAKgBAIAHIApAmIAKAJIADAEIACABIAAABIABAAIAuA1IAMANIADAEIACACIAAAAIACAEIAAAAQARAkgdAAIgKgBg");
	var mask_1_graphics_2 = new cjs.Graphics().p("ABdDhIgIgBQgFgBgFgFIgDgEIABABIgBgBIAAAAIAAgBIgBAAIAAgBIgMgNIgngrIgIgKIgBgBIAAAAIgBAAIgKgKIglgiIgDgDIgDgEIgCgBIgIgJIgkgnQgHgHAAgLQAAgKAIgHQAHgHALAAQAKABAHAHIAkAnIAJAKIACADIABAAIAAAAIAnAkIAKAJIADAEIACABIAAABIABAAIAuA1IAMANIADAEIACACIAAAAIACAEIAAAAQARAkgdAAIgKgBg");
	var mask_1_graphics_3 = new cjs.Graphics().p("ABdDhIgIgBQgFgBgFgFIgDgEIABABIgBgBIAAAAIAAgBIgBAAIAAgBIgMgNIgngrIgIgKIgBgBIAAAAIgBAAIgKgKIglgiIgDgDIgDgEIgCgBIgIgJIgkgnIgEgFQgDgBAAgKIAAgBIAAgCIgCgPIgKg8QgCgKAGgJQAGgIAKgCQAKgBAJAGQAIAGACAKIAKA9IACANIAeAhIAJAKIACADIABAAIAAAAIAnAkIAKAJIADAEIACABIAAABIABAAIAuA1IAMANIADAEIACACIAAAAIACAEIAAAAQARAkgdAAIgKgBg");
	var mask_1_graphics_4 = new cjs.Graphics().p("ABdDhIgIgBQgFgBgFgFIgDgEIABABIgBgBIAAAAIAAgBIgBAAIAAgBIgMgNIgngrIgIgKIgBgBIAAAAIgBAAIgKgKIglgiIgDgDIgDgEIgCgBIgIgJIgkgnIgEgFQgDgBAAgKIAAgBIAAgCIgCgPIgKg8QgBgIADgGQADgHAGgEQAGgEAHAAQgQgCANgqQADgJAJgFQAJgFAKADQAJADAFAJQAFAJgDAKQgKAhgJATIAKA7IACANIAeAhIAJAKIACADIABAAIAAAAIAnAkIAKAJIADAEIACABIAAABIABAAIAuA1IAMANIADAEIACACIAAAAIACAEIAAAAQARAkgdAAIgKgBg");
	var mask_1_graphics_5 = new cjs.Graphics().p("ABdDhIgIgBQgFgBgFgFIgDgEIABABIgBgBIAAAAIAAgBIgBAAIAAgBIgMgNIgngrIgIgKIgBgBIAAAAIgBAAIgKgKIglgiIgDgDIgDgEIgCgBIgIgJIgkgnIgEgFQgDgBAAgKIAAgBIAAgCIgCgPIgKg8QgBgIADgGQADgHAGgEQAGgEAHAAQgQgCANgqIAAABQACgPAmgiIAegaQAIgHAKACQAKABAGAIQAHAIgCAKQgBAKgIAHIgbAYQgWATgEAGIAAABQgKAhgJATIAKA7IACANIAeAhIAJAKIACADIABAAIAAAAIAnAkIAKAJIADAEIACABIAAABIABAAIAuA1IAMANIADAEIACACIAAAAIACAEIAAAAQARAkgdAAIgKgBg");
	var mask_1_graphics_6 = new cjs.Graphics().p("ABdDhIgIgBQgFgBgFgFIgDgEIABABIgBgBIAAAAIAAgBIgBAAIAAgBIgMgNIgngrIgIgKIgBgBIAAAAIgBAAIgKgKIglgiIgDgDIgDgEIgCgBIgIgJIgkgnIgEgFQgDgBAAgKIAAgBIAAgCIgCgPIgKg8QgBgIADgGQADgHAGgEQAGgEAHAAQgQgCANgqIAAABQACgPAmgiIAegaQAFgEAGgBIAigHIACAAQAygGAXAQQAJAGACAKQADAKgGAIQgFAJgKACQgKADgJgGQgNgGgaACIgBAAIgcAGIgXAVQgWATgEAGIAAABQgKAhgJATIAKA7IACANIAeAhIAJAKIACADIABAAIAAAAIAnAkIAKAJIADAEIACABIAAABIABAAIAuA1IAMANIADAEIACACIAAAAIACAEIAAAAQARAkgdAAIgKgBg");
	var mask_1_graphics_7 = new cjs.Graphics().p("AA9DhIgIgBQgFgBgEgFIgEgEIABABIgBgBIAAAAIAAgBIgBAAIAAgBIgMgNIglgrIgJgKIgBgBIAAAAIAAAAIgKgKIgngiIgDgDIgDgEIgCgBIgIgJIgkgnIgEgFQgDgBAAgKIAAgBIAAgCIgCgPIgKg8QgBgIADgGQADgHAGgEQAGgEAIAAQgRgCANgqIAAABQACgPAmgiIAfgaQAEgEAGgBIAjgHIACAAQAxgGAYAQQATAMAeAaIAAAAIAYAWQAIAHAAAKQABALgHAHQgHAIgKAAQgKABgIgHIgYgWIAAAAQgZgWgRgLQgNgGgbACIAAAAIgcAGIgYAVQgWATgEAGIAAABQgKAhgIATIAJA7IACANIAeAhIAKAKIACADIAAAAIAAAAIAnAkIALAJIADAEIABABIABABIAAAAIAvA1IALANIAEAEIABACIABAAIACAEIAAAAQARAkgeAAIgKgBg");
	var mask_1_graphics_8 = new cjs.Graphics().p("AAvDhIgHgBQgGgBgEgFIgDgEIAAABIgBgBIABAAIgBgBIAAAAIgBgBIgLgNIgmgrIgJgKIAAgBIgBAAIAAAAIgKgKIgmgiIgEgDIgDgEIgBgBIgJgJIgkgnIgEgFQgCgBAAgKIAAgBIgBgCIgCgPIgKg8QgBgIADgGQADgHAGgEQAHgEAHAAQgQgCAMgqIAAABQACgPAmgiIAfgaQAFgEAGgBIAjgHIACAAQAwgGAYAQQAUAMAdAaIABAAIAXAWIAAAAQAPAOgEADQALAAAHAIQAHAHAAAKQAAAKgHAIQgHAHgLAAQgFAFgngjIAAAAIgXgWIgBAAQgZgWgRgLQgNgGgaACIAAAAIgcAGIgZAVQgWATgDAGIAAABQgKAhgJATIAJA7IACANIAfAhIAJAKIACADIAAAAIABAAIAnAkIALAJIACAEIABABIABABIAAAAIAvA1IAMANIADAEIACACIAAAAIACAEIAAAAQARAkgdAAIgLgBg");
	var mask_1_graphics_9 = new cjs.Graphics().p("AgRDhIgHgBQgGgBgEgFIgDgEIAAABIgBgBIABAAIgBgBIAAAAIgBgBIgLgNIgngrIgJgKIAAgBIgBAAIAAAAIgKgKIgmgiIgEgDIgDgEIgBgBIgJgJIgkgnIgEgFQgCgBAAgKIAAgBIgBgCIgCgPIgKg8QgBgIADgGQADgHAGgEQAHgEAHAAQgQgCAMgqIAAABQACgPAmgiIAfgaQAFgEAGgBIAjgHIACAAQAxgGAYAQQATAMAdAaIABAAIAXAWIAAAAQAHAGADAEQADgLAUgcQAEgGAGgDIBYgnQAKgEAJAEQAKAEAEAJQAEAKgEAJQgDAKgKAEIhSAkQgxBEgJgGQgFAFgngjIAAAAIgXgWIgBAAQgYgWgRgLQgNgGgbACIAAAAIgcAGIgZAVQgWATgDAGIAAABQgKAhgJATIAJA7IACANIAfAhIAJAKIACADIAAAAIABAAIAnAkIALAJIADAEIABABIABABIAAAAIAvA1IAMANIACAEIACACIAAAAIACAEIAAAAQARAkgcAAIgLgBg");
	var mask_1_graphics_10 = new cjs.Graphics().p("AhSDhIgIgBQgFgBgEgFIgEgEIABABIgBgBIAAAAIAAgBIgBAAIAAgBIgMgNIgmgrIgJgKIgBgBIAAAAIAAAAIgKgKIgngiIgDgDIgDgEIgCgBIgIgJIgkgnIgEgFQgDgBAAgKIAAgBIAAgCIgCgPIgKg8QgBgIADgGQADgHAGgEQAGgEAIAAQgRgCANgqIAAABQACgPAmgiIAfgaQAEgEAGgBIAjgHIACAAQAygGAYAQQATAMAeAaIAAAAIAXAWIAAAAQAHAGADAEQADgLAUgcQAEgGAGgDIBYgnQAFgCAFAAQAFABAFACIBTAlQARgBAbA4QAcA6gOAgQgEAJgJAFQgJAEgKgEQgKgDgEgJQgEgKADgJQAFgSgRgiQgLgWAJgEQgFAAgFgCIhQgkIhIAgQgxBEgJgGQgFAFgmgjIAAAAIgYgWIAAAAQgZgWgRgLQgOgGgaACIAAAAIgdAGIgYAVQgWATgEAGIAAABQgKAhgIATIAJA7IACANIAeAhIAKAKIACADIAAAAIAAAAIAoAkIALAJIADAEIABABIABABIAAAAIAvA1IALANIAEAEIABACIABAAIACAEIAAAAQARAkgeAAIgKgBg");
	var mask_1_graphics_11 = new cjs.Graphics().p("AhSDhIgIgBQgFgBgEgFIgEgEIABABIgBgBIAAAAIAAgBIgBAAIAAgBIgMgNIgmgrIgJgKIgBgBIAAAAIAAAAIgKgKIgngiIgDgDIgDgEIgCgBIgIgJIgkgnIgEgFQgDgBAAgKIAAgBIAAgCIgCgPIgKg8QgBgIADgGQADgHAGgEQAGgEAIAAQgRgCANgqIAAABQACgPAmgiIAfgaQAEgEAGgBIAjgHIACAAQAygGAYAQQATAMAeAaIAAAAIAXAWIAAAAQAHAGADAEQADgLAUgcQAEgGAGgDIBYgnQAFgCAFAAQAFABAFACIBTAlQARgBAbA4QAcA6gOAgIAAgBQgGATgFAbIAAACQgJAhgaAUQgIAGgKgBQgLgCgGgIQgGgIACgKQABgKAIgHQAMgIAEgPQAGggAHgWIAAAAQAFgSgRgiQgLgWAJgEQgFAAgFgCIhQgkIhIAgQgxBEgJgGQgFAFgmgjIAAAAIgYgWIAAAAQgZgWgRgLQgOgGgaACIAAAAIgdAGIgYAVQgWATgEAGIAAABQgKAhgIATIAJA7IACANIAeAhIAKAKIACADIAAAAIAAAAIAoAkIALAJIADAEIABABIABABIAAAAIAvA1IALANIAEAEIABACIABAAIACAEIAAAAQARAkgeAAIgKgBg");
	var mask_1_graphics_12 = new cjs.Graphics().p("AhSDhIgIgBQgFgBgEgFIgEgEIABABIgBgBIAAAAIAAgBIgBAAIAAgBIgMgNIgmgrIgJgKIgBgBIAAAAIAAAAIgKgKIgngiIgDgDIgDgEIgCgBIgIgJIgkgnIgEgFQgDgBAAgKIAAgBIAAgCIgCgPIgKg8QgBgIADgGQADgHAGgEQAGgEAIAAQgRgCANgqIAAABQACgPAmgiIAfgaQAEgEAGgBIAjgHIACAAQAygGAYAQQATAMAeAaIAAAAIAXAWIAAAAQAHAGADAEQADgLAUgcQAEgGAGgDIBYgnQAFgCAFAAQAFABAFACIBTAlQARgBAbA4QAcA6gOAgIAAgBQgGATgFAbIAAACQgJAhgaAUIAAAAQgTAPgiAjIAAABIgYAaIgDAEIgFAGQgHAHgKAAQgOAAgFgJIgBgBQgGgFABgMQgBgEAEgGIADgFIAHgIIAYgbIABAAQAlgoAWgRIAAAAQAMgIAEgPQAGggAHgWIAAAAQAFgSgRgiQgLgWAJgEQgFAAgFgCIhQgkIhIAgQgxBEgJgGQgFAFgmgjIAAAAIgYgWIAAAAQgZgWgRgLQgOgGgaACIAAAAIgdAGIgYAVQgWATgEAGIAAABQgKAhgIATIAJA7IACANIAeAhIAKAKIACADIAAAAIAAAAIAoAkIALAJIADAEIABABIABABIAAAAIAvA1IALANIAEAEIABACIABAAIACAEIAAAAQARAkgeAAIgKgBgACkB6IAAgBIgBAAIABABg");
	var mask_1_graphics_13 = new cjs.Graphics().p("AAvDhQgIgIAAgKQgBgKAHgHIA5g+IAOgPIABgBIAAgBIABgCIADgEIAEgFIABgBIAZgbIAAgBQAmgoAWgQIAAAAQAMgJAEgNQAFgiAIgVIAAgBQAEgSgQghQgLgXAJgDIgKgDIhQgjIhIAgQgyBEgIgGQgFAEgmgiIgYgWIAAAAQgagXgRgKQgNgHgaADIgBAAIgcAGIgYAUQgWAUgEAGIAAABQgKAhgJATIAKA8IACAMIAeAhIAJAKIACACIABABIAoAkIAKAJIADADIACACIAAAAIABABIAuA0IAMAOIADAEIACACIACAEIAAAAQAUApgqgGQgEAAgEgBQgFgCgFgEIgCgDIAAgBIgBAAIgBgBIAAgBIgMgNIgngsIgIgJIgCgCIgKgJIgmgiIgDgDIgDgEIgCgBIgIgKIgkgmIgEgFQgDgBAAgKIAAgBIAAgCIgCgOIgKg+QgBgHADgHQADgGAGgEQAGgFAHABQgQgDANgpIAAABQACgPAmgjIAegaQAFgDAGgBIAjgHIACgBQAygGAXARQAUAMAeAaIAAAAIAYAWIAAAAQAGAGADAEQACgLAVgdQAEgFAGgDIBYgnQAFgCAFAAQAFAAAFACIBTAlQARAAAbA4QAbA5gNAgQgHASgEAcIgBACQgIAhgaAUQgUAOghAkIgBAAIgXAaIgEAFIAAAAIgCADIgCACIgDAEIgPAQIg4A+QgIAIgKAAQgKAAgHgGg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:18.5,y:39.2}).wait(1).to({graphics:mask_1_graphics_1,x:12.2,y:22.6}).wait(1).to({graphics:mask_1_graphics_2,x:12.2,y:22.6}).wait(1).to({graphics:mask_1_graphics_3,x:12.2,y:22.6}).wait(1).to({graphics:mask_1_graphics_4,x:12.2,y:22.6}).wait(1).to({graphics:mask_1_graphics_5,x:12.2,y:22.6}).wait(1).to({graphics:mask_1_graphics_6,x:12.2,y:22.6}).wait(1).to({graphics:mask_1_graphics_7,x:15.3,y:22.6}).wait(1).to({graphics:mask_1_graphics_8,x:16.7,y:22.6}).wait(1).to({graphics:mask_1_graphics_9,x:23.2,y:22.6}).wait(1).to({graphics:mask_1_graphics_10,x:29.7,y:22.6}).wait(1).to({graphics:mask_1_graphics_11,x:29.7,y:22.6}).wait(1).to({graphics:mask_1_graphics_12,x:29.7,y:22.6}).wait(1).to({graphics:mask_1_graphics_13,x:30.4,y:24}).wait(8).to({graphics:null,x:0,y:0}).wait(27));

	// Layer_10
	this.instance_1 = new lib.heart1();
	this.instance_1.parent = this;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(25).to({scaleX:1.05,scaleY:1.05,x:-1,y:-1},0).wait(4).to({scaleX:1,scaleY:1,x:0,y:0},0).wait(4).to({scaleX:1.05,scaleY:1.05,x:-1,y:-1},0).wait(4).to({scaleX:1,scaleY:1,x:0,y:0},0).wait(4).to({scaleX:1.05,scaleY:1.05,x:-1,y:-1},0).wait(4).to({scaleX:1,scaleY:1,x:0,y:0},0).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(43.3,56.7,11.6,10.9);
// library properties:
lib.properties = {
	id: '2983DB3F1336EA4984731F937C810E2C',
	width: 61,
	height: 47,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"heart_beat_HTML5 Canvas_atlas_.png", id:"heart_beat_HTML5 Canvas_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['2983DB3F1336EA4984731F937C810E2C'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;



var canvas, stage, exportRoot, anim_container, dom_overlay_container, fnStartAnimation;
function init() {
	canvas = document.getElementById("canvas");
	anim_container = document.getElementById("animation_container");
	dom_overlay_container = document.getElementById("dom_overlay_container");
	var comp=AdobeAn.getComposition("2983DB3F1336EA4984731F937C810E2C");
	var lib=comp.getLibrary();
	var loader = new createjs.LoadQueue(false);
	loader.addEventListener("fileload", function(evt){handleFileLoad(evt,comp)});
	loader.addEventListener("complete", function(evt){handleComplete(evt,comp)});
	var lib=comp.getLibrary();
	loader.loadManifest(lib.properties.manifest);
}
function handleFileLoad(evt, comp) {
	var images=comp.getImages();	
	if (evt && (evt.item.type == "image")) { images[evt.item.id] = evt.result; }	
}
function handleComplete(evt,comp) {
	//This function is always called, irrespective of the content. You can use the variable "stage" after it is created in token create_stage.
	var lib=comp.getLibrary();
	var ss=comp.getSpriteSheet();
	var queue = evt.target;
	var ssMetadata = lib.ssMetadata;
	for(i=0; i<ssMetadata.length; i++) {
		ss[ssMetadata[i].name] = new createjs.SpriteSheet( {"images": [queue.getResult(ssMetadata[i].name)], "frames": ssMetadata[i].frames} )
	}
	exportRoot = new lib.heart_beat_HTML5Canvas();
	stage = new lib.Stage(canvas);	
	//Registers the "tick" event listener.
	fnStartAnimation = function() {
		stage.addChild(exportRoot);
		createjs.Ticker.setFPS(lib.properties.fps);
		createjs.Ticker.addEventListener("tick", stage);
	}	    
	//Code to support hidpi screens and responsive scaling.
	function makeResponsive2(isResp, respDim, isScale, scaleType) {		
		var lastW, lastH, lastS=1;		
		window.addEventListener('resize', resizeCanvas);		
		resizeCanvas();		
		function resizeCanvas() {			
			var w = lib.properties.width, h = lib.properties.height;			
			var iw = window.innerWidth, ih=window.innerHeight;			
			var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
			if(isResp) {                
				if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
					sRatio = lastS;                
				}				
				else if(!isScale) {					
					if(iw<w || ih<h)						
						sRatio = Math.min(xRatio, yRatio);				
				}				
				else if(scaleType==1) {					
					sRatio = Math.min(xRatio, yRatio);				
				}				
				else if(scaleType==2) {					
					sRatio = Math.max(xRatio, yRatio);				
				}			
			}			
			canvas.width = w*pRatio*sRatio;			
			canvas.height = h*pRatio*sRatio;
			canvas.style.width = dom_overlay_container.style.width = anim_container.style.width =  w*sRatio+'px';				
			canvas.style.height = anim_container.style.height = dom_overlay_container.style.height = h*sRatio+'px';
			stage.scaleX = pRatio*sRatio;			
			stage.scaleY = pRatio*sRatio;			
			lastW = iw; lastH = ih; lastS = sRatio;            
			stage.tickOnUpdate = false;            
			stage.update();            
			stage.tickOnUpdate = true;		
		}
	}
	makeResponsive2(false,'both',false,1);	
	AdobeAn.compositionLoaded(lib.properties.id);
	fnStartAnimation();
}
	

