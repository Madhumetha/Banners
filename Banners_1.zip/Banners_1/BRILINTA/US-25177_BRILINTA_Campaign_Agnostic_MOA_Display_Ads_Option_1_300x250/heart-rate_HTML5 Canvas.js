(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"heart_rate_HTML5 Canvas_atlas_", frames: [[298,0,28,28],[0,0,296,194]]}
];


// symbols:



(lib.beat = function() {
	this.spriteSheet = ss["heart_rate_HTML5 Canvas_atlas_"];
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.ekg = function() {
	this.spriteSheet = ss["heart_rate_HTML5 Canvas_atlas_"];
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.dot = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.beat();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.dot, new cjs.Rectangle(0,0,28,28), null);


// stage content:
(lib.heartrate_HTML5Canvas = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Guide: Layer_3
	this.instance = new lib.dot();
	this.instance.parent = this;
	this.instance.setTransform(10,81,1,1,0,0,0,14,14);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:22.2,y:61.5},7).to({x:26.2,y:99},6).to({x:34.4,y:95},6).to({x:42.7,y:81},7).to({x:58.2,y:85},6).to({x:76.5,y:79.8},6).to({x:86.2,y:19},10).to({x:92.5,y:150.3},9).to({x:103,y:87.8},7).to({x:113.5,y:81},7).to({x:126.5,y:58.3},7).to({x:134.2,y:98.5},8).to({x:145.2,y:81},7).to({x:161.2,y:83.8},8).to({x:176.7,y:80.5},7).to({x:188,y:64.3},8).to({x:190,y:36.5},8).to({x:197,y:106},7).to({x:205.4,y:82.5},7).to({x:219.2,y:79.6},7).wait(2));

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AirWHMAAAgsNIFXAAMAAAAsNg");
	var mask_graphics_1 = new cjs.Graphics().p("Ai7WHMAAAgsNIF2AAMAAAAsNg");
	var mask_graphics_2 = new cjs.Graphics().p("AjJWHMAAAgsNIGUAAMAAAAsNg");
	var mask_graphics_3 = new cjs.Graphics().p("AjZWHMAAAgsNIGzAAMAAAAsNg");
	var mask_graphics_4 = new cjs.Graphics().p("AjoWHMAAAgsNIHRAAMAAAAsNg");
	var mask_graphics_5 = new cjs.Graphics().p("Aj3WHMAAAgsNIHvAAMAAAAsNg");
	var mask_graphics_6 = new cjs.Graphics().p("AkGWHMAAAgsNIINAAMAAAAsNg");
	var mask_graphics_7 = new cjs.Graphics().p("AkVWHMAAAgsNIIrAAMAAAAsNg");
	var mask_graphics_8 = new cjs.Graphics().p("AkYWHMAAAgsNIIxAAMAAAAsNg");
	var mask_graphics_9 = new cjs.Graphics().p("AkcWHMAAAgsNII4AAMAAAAsNg");
	var mask_graphics_10 = new cjs.Graphics().p("AkeWHMAAAgsNII+AAMAAAAsNg");
	var mask_graphics_11 = new cjs.Graphics().p("AkiWHMAAAgsNIJFAAMAAAAsNg");
	var mask_graphics_12 = new cjs.Graphics().p("AklWHMAAAgsNIJLAAMAAAAsNg");
	var mask_graphics_13 = new cjs.Graphics().p("AkoWHMAAAgsNIJRAAMAAAAsNg");
	var mask_graphics_14 = new cjs.Graphics().p("AkuWHMAAAgsNIJdAAMAAAAsNg");
	var mask_graphics_15 = new cjs.Graphics().p("Ak1WHMAAAgsNIJrAAMAAAAsNg");
	var mask_graphics_16 = new cjs.Graphics().p("Ak7WHMAAAgsNIJ3AAMAAAAsNg");
	var mask_graphics_17 = new cjs.Graphics().p("AlBWHMAAAgsNIKDAAMAAAAsNg");
	var mask_graphics_18 = new cjs.Graphics().p("AlIWHMAAAgsNIKRAAMAAAAsNg");
	var mask_graphics_19 = new cjs.Graphics().p("AlOWHMAAAgsNIKdAAMAAAAsNg");
	var mask_graphics_20 = new cjs.Graphics().p("AlVWHMAAAgsNIKrAAMAAAAsNg");
	var mask_graphics_21 = new cjs.Graphics().p("AlcWHMAAAgsNIK5AAMAAAAsNg");
	var mask_graphics_22 = new cjs.Graphics().p("AljWHMAAAgsNILHAAMAAAAsNg");
	var mask_graphics_23 = new cjs.Graphics().p("AlrWHMAAAgsNILWAAMAAAAsNg");
	var mask_graphics_24 = new cjs.Graphics().p("AlxWHMAAAgsNILjAAMAAAAsNg");
	var mask_graphics_25 = new cjs.Graphics().p("Al5WHMAAAgsNILzAAMAAAAsNg");
	var mask_graphics_26 = new cjs.Graphics().p("AmAWHMAAAgsNIMBAAMAAAAsNg");
	var mask_graphics_27 = new cjs.Graphics().p("AmNWHMAAAgsNIMbAAMAAAAsNg");
	var mask_graphics_28 = new cjs.Graphics().p("AmZWHMAAAgsNIMzAAMAAAAsNg");
	var mask_graphics_29 = new cjs.Graphics().p("AmmWHMAAAgsNINNAAMAAAAsNg");
	var mask_graphics_30 = new cjs.Graphics().p("AmzWHMAAAgsNINnAAMAAAAsNg");
	var mask_graphics_31 = new cjs.Graphics().p("Am/WHMAAAgsNIN/AAMAAAAsNg");
	var mask_graphics_32 = new cjs.Graphics().p("AnMWHMAAAgsNIOZAAMAAAAsNg");
	var mask_graphics_33 = new cjs.Graphics().p("AnZWHMAAAgsNIOzAAMAAAAsNg");
	var mask_graphics_34 = new cjs.Graphics().p("AnnWHMAAAgsNIPOAAMAAAAsNg");
	var mask_graphics_35 = new cjs.Graphics().p("An0WHMAAAgsNIPpAAMAAAAsNg");
	var mask_graphics_36 = new cjs.Graphics().p("AoCWHMAAAgsNIQFAAMAAAAsNg");
	var mask_graphics_37 = new cjs.Graphics().p("AoPWHMAAAgsNIQfAAMAAAAsNg");
	var mask_graphics_38 = new cjs.Graphics().p("AocWHMAAAgsNIQ6AAMAAAAsNg");
	var mask_graphics_39 = new cjs.Graphics().p("AoiWHMAAAgsNIRFAAMAAAAsNg");
	var mask_graphics_40 = new cjs.Graphics().p("AonWHMAAAgsNIRPAAMAAAAsNg");
	var mask_graphics_41 = new cjs.Graphics().p("AotWHMAAAgsNIRbAAMAAAAsNg");
	var mask_graphics_42 = new cjs.Graphics().p("AoyWHMAAAgsNIRlAAMAAAAsNg");
	var mask_graphics_43 = new cjs.Graphics().p("Ao4WHMAAAgsNIRxAAMAAAAsNg");
	var mask_graphics_44 = new cjs.Graphics().p("Ao9WHMAAAgsNIR7AAMAAAAsNg");
	var mask_graphics_45 = new cjs.Graphics().p("ApCWHMAAAgsNISFAAMAAAAsNg");
	var mask_graphics_46 = new cjs.Graphics().p("ApIWHMAAAgsNISRAAMAAAAsNg");
	var mask_graphics_47 = new cjs.Graphics().p("ApNWHMAAAgsNISbAAMAAAAsNg");
	var mask_graphics_48 = new cjs.Graphics().p("ApTWHMAAAgsNISnAAMAAAAsNg");
	var mask_graphics_49 = new cjs.Graphics().p("ApXWHMAAAgsNISvAAMAAAAsNg");
	var mask_graphics_50 = new cjs.Graphics().p("ApbWHMAAAgsNIS3AAMAAAAsNg");
	var mask_graphics_51 = new cjs.Graphics().p("ApfWHMAAAgsNIS/AAMAAAAsNg");
	var mask_graphics_52 = new cjs.Graphics().p("ApkWHMAAAgsNITIAAMAAAAsNg");
	var mask_graphics_53 = new cjs.Graphics().p("ApnWHMAAAgsNITPAAMAAAAsNg");
	var mask_graphics_54 = new cjs.Graphics().p("AprWHMAAAgsNITYAAMAAAAsNg");
	var mask_graphics_55 = new cjs.Graphics().p("ApwWHMAAAgsNIThAAMAAAAsNg");
	var mask_graphics_56 = new cjs.Graphics().p("Ap0WHMAAAgsNITpAAMAAAAsNg");
	var mask_graphics_57 = new cjs.Graphics().p("Ap4WHMAAAgsNITxAAMAAAAsNg");
	var mask_graphics_58 = new cjs.Graphics().p("Ap/WHMAAAgsNIT/AAMAAAAsNg");
	var mask_graphics_59 = new cjs.Graphics().p("AqFWHMAAAgsNIULAAMAAAAsNg");
	var mask_graphics_60 = new cjs.Graphics().p("AqMWHMAAAgsNIUZAAMAAAAsNg");
	var mask_graphics_61 = new cjs.Graphics().p("AqSWHMAAAgsNIUlAAMAAAAsNg");
	var mask_graphics_62 = new cjs.Graphics().p("AqZWHMAAAgsNIUzAAMAAAAsNg");
	var mask_graphics_63 = new cjs.Graphics().p("AqgWHMAAAgsNIVBAAMAAAAsNg");
	var mask_graphics_64 = new cjs.Graphics().p("AqmWHMAAAgsNIVNAAMAAAAsNg");
	var mask_graphics_65 = new cjs.Graphics().p("AquWHMAAAgsNIVdAAMAAAAsNg");
	var mask_graphics_66 = new cjs.Graphics().p("Aq2WHMAAAgsNIVtAAMAAAAsNg");
	var mask_graphics_67 = new cjs.Graphics().p("Aq+WHMAAAgsNIV9AAMAAAAsNg");
	var mask_graphics_68 = new cjs.Graphics().p("ArFWHMAAAgsNIWLAAMAAAAsNg");
	var mask_graphics_69 = new cjs.Graphics().p("ArNWHMAAAgsNIWbAAMAAAAsNg");
	var mask_graphics_70 = new cjs.Graphics().p("ArVWHMAAAgsNIWrAAMAAAAsNg");
	var mask_graphics_71 = new cjs.Graphics().p("ArdWHMAAAgsNIW7AAMAAAAsNg");
	var mask_graphics_72 = new cjs.Graphics().p("ArmWHMAAAgsNIXNAAMAAAAsNg");
	var mask_graphics_73 = new cjs.Graphics().p("ArvWHMAAAgsNIXfAAMAAAAsNg");
	var mask_graphics_74 = new cjs.Graphics().p("Ar3WHMAAAgsNIXwAAMAAAAsNg");
	var mask_graphics_75 = new cjs.Graphics().p("AsAWHMAAAgsNIYBAAMAAAAsNg");
	var mask_graphics_76 = new cjs.Graphics().p("AsJWHMAAAgsNIYTAAMAAAAsNg");
	var mask_graphics_77 = new cjs.Graphics().p("AsSWHMAAAgsNIYlAAMAAAAsNg");
	var mask_graphics_78 = new cjs.Graphics().p("AsbWHMAAAgsNIY2AAMAAAAsNg");
	var mask_graphics_79 = new cjs.Graphics().p("AsgWHMAAAgsNIZBAAMAAAAsNg");
	var mask_graphics_80 = new cjs.Graphics().p("AsmWHMAAAgsNIZNAAMAAAAsNg");
	var mask_graphics_81 = new cjs.Graphics().p("AsrWHMAAAgsNIZXAAMAAAAsNg");
	var mask_graphics_82 = new cjs.Graphics().p("AswWHMAAAgsNIZhAAMAAAAsNg");
	var mask_graphics_83 = new cjs.Graphics().p("As2WHMAAAgsNIZtAAMAAAAsNg");
	var mask_graphics_84 = new cjs.Graphics().p("As7WHMAAAgsNIZ3AAMAAAAsNg");
	var mask_graphics_85 = new cjs.Graphics().p("AtBWHMAAAgsNIaCAAMAAAAsNg");
	var mask_graphics_86 = new cjs.Graphics().p("AtGWHMAAAgsNIaNAAMAAAAsNg");
	var mask_graphics_87 = new cjs.Graphics().p("AtOWHMAAAgsNIacAAMAAAAsNg");
	var mask_graphics_88 = new cjs.Graphics().p("AtVWHMAAAgsNIarAAMAAAAsNg");
	var mask_graphics_89 = new cjs.Graphics().p("AtcWHMAAAgsNIa5AAMAAAAsNg");
	var mask_graphics_90 = new cjs.Graphics().p("AtjWHMAAAgsNIbHAAMAAAAsNg");
	var mask_graphics_91 = new cjs.Graphics().p("AtrWHMAAAgsNIbXAAMAAAAsNg");
	var mask_graphics_92 = new cjs.Graphics().p("AtyWHMAAAgsNIblAAMAAAAsNg");
	var mask_graphics_93 = new cjs.Graphics().p("At5WHMAAAgsNIbzAAMAAAAsNg");
	var mask_graphics_94 = new cjs.Graphics().p("AuEWHMAAAgsNIcJAAMAAAAsNg");
	var mask_graphics_95 = new cjs.Graphics().p("AuOWHMAAAgsNIcdAAMAAAAsNg");
	var mask_graphics_96 = new cjs.Graphics().p("AuYWHMAAAgsNIcxAAMAAAAsNg");
	var mask_graphics_97 = new cjs.Graphics().p("AuiWHMAAAgsNIdFAAMAAAAsNg");
	var mask_graphics_98 = new cjs.Graphics().p("AusWHMAAAgsNIdZAAMAAAAsNg");
	var mask_graphics_99 = new cjs.Graphics().p("Au2WHMAAAgsNIdtAAMAAAAsNg");
	var mask_graphics_100 = new cjs.Graphics().p("AvAWHMAAAgsNIeBAAMAAAAsNg");
	var mask_graphics_101 = new cjs.Graphics().p("AvKWHMAAAgsNIeVAAMAAAAsNg");
	var mask_graphics_102 = new cjs.Graphics().p("AvWWHMAAAgsNIetAAMAAAAsNg");
	var mask_graphics_103 = new cjs.Graphics().p("AvhWHMAAAgsNIfDAAMAAAAsNg");
	var mask_graphics_104 = new cjs.Graphics().p("AvtWHMAAAgsNIfbAAMAAAAsNg");
	var mask_graphics_105 = new cjs.Graphics().p("Av4WHMAAAgsNIfxAAMAAAAsNg");
	var mask_graphics_106 = new cjs.Graphics().p("AwDWHMAAAgsNMAgHAAAMAAAAsNg");
	var mask_graphics_107 = new cjs.Graphics().p("AwPWHMAAAgsNMAgfAAAMAAAAsNg");
	var mask_graphics_108 = new cjs.Graphics().p("AwaWHMAAAgsNMAg1AAAMAAAAsNg");
	var mask_graphics_109 = new cjs.Graphics().p("AwgWHMAAAgsNMAhBAAAMAAAAsNg");
	var mask_graphics_110 = new cjs.Graphics().p("AwlWHMAAAgsNMAhLAAAMAAAAsNg");
	var mask_graphics_111 = new cjs.Graphics().p("AwqWHMAAAgsNMAhVAAAMAAAAsNg");
	var mask_graphics_112 = new cjs.Graphics().p("AwvWHMAAAgsNMAhfAAAMAAAAsNg");
	var mask_graphics_113 = new cjs.Graphics().p("Aw0WHMAAAgsNMAhpAAAMAAAAsNg");
	var mask_graphics_114 = new cjs.Graphics().p("Aw5WHMAAAgsNMAhzAAAMAAAAsNg");
	var mask_graphics_115 = new cjs.Graphics().p("Aw+WHMAAAgsNMAh9AAAMAAAAsNg");
	var mask_graphics_116 = new cjs.Graphics().p("AxDWHMAAAgsNMAiHAAAMAAAAsNg");
	var mask_graphics_117 = new cjs.Graphics().p("AxGWHMAAAgsNMAiMAAAMAAAAsNg");
	var mask_graphics_118 = new cjs.Graphics().p("AxIWHMAAAgsNMAiRAAAMAAAAsNg");
	var mask_graphics_119 = new cjs.Graphics().p("AxKWHMAAAgsNMAiVAAAMAAAAsNg");
	var mask_graphics_120 = new cjs.Graphics().p("AxNWHMAAAgsNMAibAAAMAAAAsNg");
	var mask_graphics_121 = new cjs.Graphics().p("AxPWHMAAAgsNMAifAAAMAAAAsNg");
	var mask_graphics_122 = new cjs.Graphics().p("AxRWHMAAAgsNMAijAAAMAAAAsNg");
	var mask_graphics_123 = new cjs.Graphics().p("AxUWHMAAAgsNMAipAAAMAAAAsNg");
	var mask_graphics_124 = new cjs.Graphics().p("AxWWHMAAAgsNMAitAAAMAAAAsNg");
	var mask_graphics_125 = new cjs.Graphics().p("AxbWHMAAAgsNMAi3AAAMAAAAsNg");
	var mask_graphics_126 = new cjs.Graphics().p("AxgWHMAAAgsNMAjBAAAMAAAAsNg");
	var mask_graphics_127 = new cjs.Graphics().p("AxmWHMAAAgsNMAjNAAAMAAAAsNg");
	var mask_graphics_128 = new cjs.Graphics().p("AxqWHMAAAgsNMAjVAAAMAAAAsNg");
	var mask_graphics_129 = new cjs.Graphics().p("AxwWHMAAAgsNMAjhAAAMAAAAsNg");
	var mask_graphics_130 = new cjs.Graphics().p("Ax1WHMAAAgsNMAjrAAAMAAAAsNg");
	var mask_graphics_131 = new cjs.Graphics().p("Ax6WHMAAAgsNMAj1AAAMAAAAsNg");
	var mask_graphics_132 = new cjs.Graphics().p("AyBWHMAAAgsNMAkDAAAMAAAAsNg");
	var mask_graphics_133 = new cjs.Graphics().p("AyIWHMAAAgsNMAkSAAAMAAAAsNg");
	var mask_graphics_134 = new cjs.Graphics().p("AyQWHMAAAgsNMAkhAAAMAAAAsNg");
	var mask_graphics_135 = new cjs.Graphics().p("AyXWHMAAAgsNMAkvAAAMAAAAsNg");
	var mask_graphics_136 = new cjs.Graphics().p("AyeWHMAAAgsNMAk9AAAMAAAAsNg");
	var mask_graphics_137 = new cjs.Graphics().p("AylWHMAAAgsNMAlLAAAMAAAAsNg");
	var mask_graphics_138 = new cjs.Graphics().p("AysWHMAAAgsNMAlZAAAMAAAAsNg");
	var mask_graphics_139 = new cjs.Graphics().p("A0MWHMAAAgsNMAoZAAAMAAAAsNg");
	var mask_graphics_140 = new cjs.Graphics().p("A1sWHMAAAgsNMArZAAAMAAAAsNg");
	var mask_graphics_141 = new cjs.Graphics().p("A3MWHMAAAgsNMAuZAAAMAAAAsNg");
	var mask_graphics_142 = new cjs.Graphics().p("A4sWHMAAAgsNMAxYAAAMAAAAsNg");
	var mask_graphics_143 = new cjs.Graphics().p("A6LWHMAAAgsNMA0XAAAMAAAAsNg");
	var mask_graphics_144 = new cjs.Graphics().p("A7rWHMAAAgsNMA3XAAAMAAAAsNg");
	var mask_graphics_145 = new cjs.Graphics().p("A9LWHMAAAgsNMA6XAAAMAAAAsNg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-16.7,y:79.4}).wait(1).to({graphics:mask_graphics_1,x:-15.1,y:79.4}).wait(1).to({graphics:mask_graphics_2,x:-13.6,y:79.4}).wait(1).to({graphics:mask_graphics_3,x:-12,y:79.4}).wait(1).to({graphics:mask_graphics_4,x:-10.5,y:79.4}).wait(1).to({graphics:mask_graphics_5,x:-8.9,y:79.4}).wait(1).to({graphics:mask_graphics_6,x:-7.4,y:79.4}).wait(1).to({graphics:mask_graphics_7,x:-5.8,y:79.4}).wait(1).to({graphics:mask_graphics_8,x:-5.5,y:79.4}).wait(1).to({graphics:mask_graphics_9,x:-5.2,y:79.4}).wait(1).to({graphics:mask_graphics_10,x:-4.8,y:79.4}).wait(1).to({graphics:mask_graphics_11,x:-4.5,y:79.4}).wait(1).to({graphics:mask_graphics_12,x:-4.2,y:79.4}).wait(1).to({graphics:mask_graphics_13,x:-3.9,y:79.4}).wait(1).to({graphics:mask_graphics_14,x:-3.2,y:79.4}).wait(1).to({graphics:mask_graphics_15,x:-2.6,y:79.4}).wait(1).to({graphics:mask_graphics_16,x:-1.9,y:79.4}).wait(1).to({graphics:mask_graphics_17,x:-1.3,y:79.4}).wait(1).to({graphics:mask_graphics_18,x:-0.7,y:79.4}).wait(1).to({graphics:mask_graphics_19,x:0,y:79.4}).wait(1).to({graphics:mask_graphics_20,x:0.7,y:79.4}).wait(1).to({graphics:mask_graphics_21,x:1.4,y:79.4}).wait(1).to({graphics:mask_graphics_22,x:2.2,y:79.4}).wait(1).to({graphics:mask_graphics_23,x:2.9,y:79.4}).wait(1).to({graphics:mask_graphics_24,x:3.7,y:79.4}).wait(1).to({graphics:mask_graphics_25,x:4.4,y:79.4}).wait(1).to({graphics:mask_graphics_26,x:5.1,y:79.4}).wait(1).to({graphics:mask_graphics_27,x:6.4,y:79.4}).wait(1).to({graphics:mask_graphics_28,x:7.7,y:79.4}).wait(1).to({graphics:mask_graphics_29,x:9,y:79.4}).wait(1).to({graphics:mask_graphics_30,x:10.3,y:79.4}).wait(1).to({graphics:mask_graphics_31,x:11.6,y:79.4}).wait(1).to({graphics:mask_graphics_32,x:12.8,y:79.4}).wait(1).to({graphics:mask_graphics_33,x:14.2,y:79.4}).wait(1).to({graphics:mask_graphics_34,x:15.6,y:79.4}).wait(1).to({graphics:mask_graphics_35,x:16.9,y:79.4}).wait(1).to({graphics:mask_graphics_36,x:18.3,y:79.4}).wait(1).to({graphics:mask_graphics_37,x:19.7,y:79.4}).wait(1).to({graphics:mask_graphics_38,x:21,y:79.4}).wait(1).to({graphics:mask_graphics_39,x:21.6,y:79.4}).wait(1).to({graphics:mask_graphics_40,x:22.1,y:79.4}).wait(1).to({graphics:mask_graphics_41,x:22.6,y:79.4}).wait(1).to({graphics:mask_graphics_42,x:23.2,y:79.4}).wait(1).to({graphics:mask_graphics_43,x:23.8,y:79.4}).wait(1).to({graphics:mask_graphics_44,x:24.3,y:79.4}).wait(1).to({graphics:mask_graphics_45,x:24.8,y:79.4}).wait(1).to({graphics:mask_graphics_46,x:25.4,y:79.4}).wait(1).to({graphics:mask_graphics_47,x:25.9,y:79.4}).wait(1).to({graphics:mask_graphics_48,x:26.5,y:79.4}).wait(1).to({graphics:mask_graphics_49,x:26.9,y:79.4}).wait(1).to({graphics:mask_graphics_50,x:27.3,y:79.4}).wait(1).to({graphics:mask_graphics_51,x:27.7,y:79.4}).wait(1).to({graphics:mask_graphics_52,x:28.2,y:79.4}).wait(1).to({graphics:mask_graphics_53,x:28.6,y:79.4}).wait(1).to({graphics:mask_graphics_54,x:29,y:79.4}).wait(1).to({graphics:mask_graphics_55,x:29.4,y:79.4}).wait(1).to({graphics:mask_graphics_56,x:29.9,y:79.4}).wait(1).to({graphics:mask_graphics_57,x:30.3,y:79.4}).wait(1).to({graphics:mask_graphics_58,x:30.9,y:79.4}).wait(1).to({graphics:mask_graphics_59,x:31.6,y:79.4}).wait(1).to({graphics:mask_graphics_60,x:32.3,y:79.4}).wait(1).to({graphics:mask_graphics_61,x:32.9,y:79.4}).wait(1).to({graphics:mask_graphics_62,x:33.6,y:79.4}).wait(1).to({graphics:mask_graphics_63,x:34.3,y:79.4}).wait(1).to({graphics:mask_graphics_64,x:34.9,y:79.4}).wait(1).to({graphics:mask_graphics_65,x:35.7,y:79.4}).wait(1).to({graphics:mask_graphics_66,x:36.5,y:79.4}).wait(1).to({graphics:mask_graphics_67,x:37.3,y:79.4}).wait(1).to({graphics:mask_graphics_68,x:38.1,y:79.4}).wait(1).to({graphics:mask_graphics_69,x:38.9,y:79.4}).wait(1).to({graphics:mask_graphics_70,x:39.7,y:79.4}).wait(1).to({graphics:mask_graphics_71,x:40.5,y:79.4}).wait(1).to({graphics:mask_graphics_72,x:41.3,y:79.4}).wait(1).to({graphics:mask_graphics_73,x:42.2,y:79.4}).wait(1).to({graphics:mask_graphics_74,x:43.1,y:79.4}).wait(1).to({graphics:mask_graphics_75,x:44,y:79.4}).wait(1).to({graphics:mask_graphics_76,x:44.9,y:79.4}).wait(1).to({graphics:mask_graphics_77,x:45.8,y:79.4}).wait(1).to({graphics:mask_graphics_78,x:46.7,y:79.4}).wait(1).to({graphics:mask_graphics_79,x:47.2,y:79.4}).wait(1).to({graphics:mask_graphics_80,x:47.8,y:79.4}).wait(1).to({graphics:mask_graphics_81,x:48.3,y:79.4}).wait(1).to({graphics:mask_graphics_82,x:48.9,y:79.4}).wait(1).to({graphics:mask_graphics_83,x:49.4,y:79.4}).wait(1).to({graphics:mask_graphics_84,x:50,y:79.4}).wait(1).to({graphics:mask_graphics_85,x:50.5,y:79.4}).wait(1).to({graphics:mask_graphics_86,x:51.1,y:79.4}).wait(1).to({graphics:mask_graphics_87,x:51.8,y:79.4}).wait(1).to({graphics:mask_graphics_88,x:52.5,y:79.4}).wait(1).to({graphics:mask_graphics_89,x:53.3,y:79.4}).wait(1).to({graphics:mask_graphics_90,x:54,y:79.4}).wait(1).to({graphics:mask_graphics_91,x:54.8,y:79.4}).wait(1).to({graphics:mask_graphics_92,x:55.5,y:79.4}).wait(1).to({graphics:mask_graphics_93,x:56.3,y:79.4}).wait(1).to({graphics:mask_graphics_94,x:57.3,y:79.4}).wait(1).to({graphics:mask_graphics_95,x:58.3,y:79.4}).wait(1).to({graphics:mask_graphics_96,x:59.3,y:79.4}).wait(1).to({graphics:mask_graphics_97,x:60.3,y:79.4}).wait(1).to({graphics:mask_graphics_98,x:61.4,y:79.4}).wait(1).to({graphics:mask_graphics_99,x:62.4,y:79.4}).wait(1).to({graphics:mask_graphics_100,x:63.4,y:79.4}).wait(1).to({graphics:mask_graphics_101,x:64.4,y:79.4}).wait(1).to({graphics:mask_graphics_102,x:65.5,y:79.4}).wait(1).to({graphics:mask_graphics_103,x:66.7,y:79.4}).wait(1).to({graphics:mask_graphics_104,x:67.8,y:79.4}).wait(1).to({graphics:mask_graphics_105,x:69,y:79.4}).wait(1).to({graphics:mask_graphics_106,x:70.2,y:79.4}).wait(1).to({graphics:mask_graphics_107,x:71.3,y:79.4}).wait(1).to({graphics:mask_graphics_108,x:72.5,y:79.4}).wait(1).to({graphics:mask_graphics_109,x:73,y:79.4}).wait(1).to({graphics:mask_graphics_110,x:73.5,y:79.4}).wait(1).to({graphics:mask_graphics_111,x:74,y:79.4}).wait(1).to({graphics:mask_graphics_112,x:74.5,y:79.4}).wait(1).to({graphics:mask_graphics_113,x:75.1,y:79.4}).wait(1).to({graphics:mask_graphics_114,x:75.6,y:79.4}).wait(1).to({graphics:mask_graphics_115,x:76.1,y:79.4}).wait(1).to({graphics:mask_graphics_116,x:76.6,y:79.4}).wait(1).to({graphics:mask_graphics_117,x:76.8,y:79.4}).wait(1).to({graphics:mask_graphics_118,x:77.1,y:79.4}).wait(1).to({graphics:mask_graphics_119,x:77.3,y:79.4}).wait(1).to({graphics:mask_graphics_120,x:77.5,y:79.4}).wait(1).to({graphics:mask_graphics_121,x:77.8,y:79.4}).wait(1).to({graphics:mask_graphics_122,x:78,y:79.4}).wait(1).to({graphics:mask_graphics_123,x:78.2,y:79.4}).wait(1).to({graphics:mask_graphics_124,x:78.5,y:79.4}).wait(1).to({graphics:mask_graphics_125,x:79,y:79.4}).wait(1).to({graphics:mask_graphics_126,x:79.5,y:79.4}).wait(1).to({graphics:mask_graphics_127,x:80,y:79.4}).wait(1).to({graphics:mask_graphics_128,x:80.6,y:79.4}).wait(1).to({graphics:mask_graphics_129,x:81.1,y:79.4}).wait(1).to({graphics:mask_graphics_130,x:81.6,y:79.4}).wait(1).to({graphics:mask_graphics_131,x:82.1,y:79.4}).wait(1).to({graphics:mask_graphics_132,x:82.8,y:79.4}).wait(1).to({graphics:mask_graphics_133,x:83.6,y:79.4}).wait(1).to({graphics:mask_graphics_134,x:84.3,y:79.4}).wait(1).to({graphics:mask_graphics_135,x:85,y:79.4}).wait(1).to({graphics:mask_graphics_136,x:85.7,y:79.4}).wait(1).to({graphics:mask_graphics_137,x:86.5,y:79.4}).wait(1).to({graphics:mask_graphics_138,x:87.2,y:79.4}).wait(1).to({graphics:mask_graphics_139,x:96.8,y:79.4}).wait(1).to({graphics:mask_graphics_140,x:106.4,y:79.4}).wait(1).to({graphics:mask_graphics_141,x:116,y:79.4}).wait(1).to({graphics:mask_graphics_142,x:125.7,y:79.4}).wait(1).to({graphics:mask_graphics_143,x:135.3,y:79.4}).wait(1).to({graphics:mask_graphics_144,x:144.9,y:79.4}).wait(1).to({graphics:mask_graphics_145,x:154.5,y:79.4}).wait(2));

	// Layer_2
	this.instance_1 = new lib.ekg();
	this.instance_1.parent = this;
	this.instance_1.setTransform(8,5);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(147));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(146,167,28,28);
// library properties:
lib.properties = {
	id: 'BF1B2DB4495B7E488C5C07C57D11181C',
	width: 300,
	height: 200,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"heart_rate_HTML5 Canvas_atlas_.png", id:"heart_rate_HTML5 Canvas_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['BF1B2DB4495B7E488C5C07C57D11181C'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;